---
name: Sovereign Defence Intelligence
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#dbc2b0'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#a38c7c'
  outline-variant: '#554336'
  surface-tint: '#ffb77d'
  primary: '#ffb77d'
  on-primary: '#4d2600'
  primary-container: '#d97707'
  on-primary-container: '#432100'
  inverse-primary: '#904d00'
  secondary: '#b4c5ff'
  on-secondary: '#002a78'
  secondary-container: '#0053db'
  on-secondary-container: '#cdd7ff'
  tertiary: '#7bd0ff'
  on-tertiary: '#00354a'
  tertiary-container: '#009bd1'
  on-tertiary-container: '#002d40'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcc3'
  primary-fixed-dim: '#ffb77d'
  on-primary-fixed: '#2f1500'
  on-primary-fixed-variant: '#6e3900'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  code-telemetry:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, precise, and mission-critical visual presence tailored for Australian defence industry strategic analysis, national security think tanks, and executive procurement intelligence. 

The aesthetic is anchored in **Tactical Precision Minimalism** fused with **High-Density Strategic Data Visualisation**. It steers away from generic corporate tropes, adopting the crisp, calculated discipline of advanced aerospace telemetry, naval command displays, and confidential strategic intelligence dossiers.

### Core Attributes
- **Authoritative & Sober:** Signals uncompromising geopolitical rigor, classified-level analytical credibility, and technical maturity.
- **Architectural & Structured:** High-order modular grids, visible technical division lines, and surgical alignment echo defence architecture and advanced systems engineering.
- **Controlled Strategic Energy:** Predominantly deep oceanic night tones accented with strategic amber-gold (paying homage to sovereign Australian resourcefulness) and tactical radar blues.

### Emotional Target
The user—whether a senior defence contractor, naval acquisitions director, or strategic policy advisor—must feel a sense of absolute precision, high analytical clarity, and dependable sovereign strategic capability.

## Colors

The palette operates in a default tactical dark mode engineered for high-prolonged operational focus and zero visual glare.

### Strategic Foundation Palette
- **Deep Maritime Abyss (`#0A192F`):** Canvas bedrock and root application viewport.
- **Command Slate (`#0F172A` / `#1E293B`):** Structural panels, analytical card containers, and sectional tiers.
- **Border Matrix (`#334155` at 40-70% alpha):** Precision separator hair lines for structural modularity.

### Accent & Telemetry
- **Sovereign Gold / Amber Core (`#D97706`, `#F59E0B`):** Reserved for strategic priorities, critical impact markers, executive highlights, and primary key actions.
- **Tactical Blue Spectrum (`#2563EB`, `#38BDF8`):** Denotes active system states, intelligence feeds, dynamic analytics, and technology status indicators.
- **Clean Tactical Readout (`#F8FAFC` & `#94A3B8`):** High-legibility text hierarchy engineered for data tables, strategic briefing prose, and metadata tags.

## Typography

The typographic hierarchy merges industrial technicality with authoritative briefing legibility:

- **Display & Headlines (Space Grotesk):** Provides engineered, aerodynamic precision with structured geometric cuts that echo aerospace drafting and military nomenclature.
- **Analytical Prose (Hanken Grotesk):** Clean, crisp, neutral, and readable across dense defence whitepapers, procurement assessments, and multi-column strategic analysis.
- **Telemetry, Classification & Metadata (JetBrains Mono):** Monospaced discipline applied to timestamps, defence capability codes (e.g., `ADF-SEA-1000`, `LAND-400`), classification badges, and numeric data arrays.

## Layout & Spacing

The layout is built upon a **12-column rigid modular matrix** reminiscent of military operational mapping grids and technical blueprint schematics.

### Spatial Discipline
- **Grid Structure:** 12-column desktop layout (`margin: 3rem`, `gutter: 1.5rem`) collapsing to 6 columns on tablet and 4 columns on mobile devices (`margin: 1.25rem`, `gutter: 1rem`).
- **Dense Tactical Rhythm:** Spacing between interrelated data attributes prioritizes compactness (`space-xs` to `space-sm`) to maximize analytical situational awareness without clutter.
- **Section Breaks:** Strategic intelligence briefings employ deliberate section divides marked by thin technical demarcation lines (`#1E293B`) rather than excessive empty white space.

## Elevation & Depth

This design system avoids soft, floating consumer-grade shadows in favor of **Layered Tonal Surfaces and Crisp Micro-Outlines**:

### Elevation Mechanics
- **Base Canvas (Level 0):** Hex `#0A192F` (Deep Maritime Abyss) — anchoring background.
- **Operational Deck (Level 1):** Hex `#0F172A` with a crisp 1px border of `rgba(51, 65, 85, 0.45)`.
- **Active Card & Focus Matrix (Level 2):** Hex `#1E293B` elevated with an ultra-subtle amber or tactical blue ambient hairline highlight (`rgba(217, 119, 6, 0.2)` or `rgba(37, 99, 235, 0.25)`).
- **Popovers & Overlays (Level 3):** Frosted low-bleed surface (`#0F172A` with `backdrop-filter: blur(12px)`) framed by a surgical 1px border (`#334155`).

Drop shadows, when applied strictly to dropdowns or modals, are direct and restrained: `0 8px 24px -4px rgba(2, 6, 23, 0.75)`.

## Shapes

The shape system adopts a **Sharp-to-Soft Architectural Corner Profile (0.25rem / 4px base)**:

- Pill-shaped elements and large circular radiuses are strictly prohibited to preserve the tone of defence-grade hardware and classified briefings.
- Tactical containers, analytical cards, data tables, and input elements utilize `rounded-sm` (0.25rem / 4px).
- Small functional tags and telemetry badges maintain tight 2px or 4px radiuses to reinforce structural precision.
- Technical cards may optionally feature chamfered or notched corner accents in bespoke tactical callout modules.

## Components

### 1. Buttons
- **Primary Strategic Action:** Solid Australian Gold (`#D97706`), text in `#0A192F` (JetBrains Mono uppercase bold), subtle hover transition to `#F59E0B` with zero elevation jump.
- **Secondary Command Action:** Outlined 1px `#334155` background transparent, hover fill `rgba(37, 99, 235, 0.12)` with tactical blue border (`#2563EB`) and text in `#F8FAFC`.
- **Operational Ghost:** High-contrast neutral text (`#94A3B8`), hover color `#F8FAFC`, paired with an arrow or telemetry coordinate glyph.

### 2. Tactical Chips & Classification Badges
- Built with `code-telemetry` (JetBrains Mono, 11px uppercase).
- **Classification / Threat Level Indicators:**
  - *Restricted / Critical:* Amber background (`rgba(217, 119, 6, 0.15)`), border `1px solid #D97706`, text `#F59E0B`.
  - *Active Capability / Maritime / Air:* Tactical Blue background (`rgba(37, 99, 235, 0.15)`), border `1px solid #2563EB`, text `#38BDF8`.
  - *Sovereign Supply / Baseline:* Slate background (`rgba(51, 65, 85, 0.3)`), border `1px solid #334155`, text `#94A3B8`.

### 3. Intelligence Briefing Cards & Matrix Modules
- **Structure:** Level 1 background (`#0F172A`), enclosed in a 1px border (`#1E293B`).
- **Interactive State:** Border shifts cleanly to `#38BDF8` or `#D97706` at 50% opacity on cursor focus, accompanied by a 2px top accent line.
- **Card Header:** Houses report identifier (e.g., `DOC // AUS-DEF-2025-Q1`) in JetBrains Mono alongside date and classification badge.

### 4. Form Inputs & Search Filters
- Background `#0A192F` inset within `#0F172A` cards, framed with 1px `#334155`.
- Active focus state: Hairline border glow `#2563EB` with zero blur spread.
- Text: Crisp `#F8FAFC`, placeholder text in `#64748B`.

### 5. Checkboxes & Filter Selectors
- Rigid square boxes (2px border radius).
- Unchecked: `1px solid #475569`.
- Checked: Tactical Blue (`#2563EB`) or Gold (`#D97706`) with an angular tactical cross or checkmark.

### 6. Strategic Capability Matrix Grid
- Dense data table using alternating subtle row shading (`#0A192F` and `#0F172A`).
- Precision divider lines (`1px solid #1E293B`).
- Numerical telemetry aligned right in JetBrains Mono; project and capability descriptions aligned left in Hanken Grotesk.